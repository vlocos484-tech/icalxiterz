import "server-only";
import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import bcrypt from "bcryptjs";
import { sql } from "@/lib/db";

const COOKIE = "icalxmodz_session";
const secret = () => new TextEncoder().encode(process.env.AUTH_SECRET || "invalid-build-secret-do-not-use");
export type Role = "owner" | "reseller";
export type User = { id: number; email: string; role: Role; balance?: number };
export const hashPassword = (password: string) => bcrypt.hash(password, 12);
export const verifyPassword = (password: string, hash: string) => bcrypt.compare(password, hash);

export async function createSession(user: User) {
  if (!process.env.AUTH_SECRET || process.env.AUTH_SECRET.length < 32) throw new Error("AUTH_SECRET must be at least 32 characters.");
  const token = await new SignJWT({ email: user.email, role: user.role }).setProtectedHeader({ alg: "HS256" }).setSubject(String(user.id)).setIssuedAt().setExpirationTime("7d").sign(secret());
  (await cookies()).set(COOKIE, token, { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax", path: "/", maxAge: 604800 });
}
export async function destroySession() {
  (await cookies()).set(COOKIE, "", { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax", path: "/", maxAge: 0 });
}
export async function getSession(): Promise<User | null> {
  const token = (await cookies()).get(COOKIE)?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, secret());
    const id = Number(payload.sub);
    if (!Number.isSafeInteger(id) || id < 1) return null;
    const rows = await sql`SELECT id,email,role,active,expires_at,balance FROM users WHERE id=${id} LIMIT 1`;
    const user = rows[0];
    if (!user || !user.active || !["owner", "reseller"].includes(user.role)) return null;
    if (user.role === "reseller" && user.expires_at && new Date(user.expires_at) <= new Date()) return null;
    return { id: Number(user.id), email: String(user.email), role: user.role, balance: Number(user.balance) };
  } catch { return null; }
}
export async function requireUser() {
  const user = await getSession();
  if (!user) redirect("/login");
  return user;
}
export async function requireOwner() {
  const user = await requireUser();
  if (user.role !== "owner") redirect("/dashboard");
  return user;
}
