"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { sql } from "@/lib/db";
import { createSession, destroySession, getSession, requireOwner, verifyPassword, hashPassword } from "@/lib/auth";

const value = (form: FormData, key: string) => String(form.get(key) || "").trim();
function integer(raw: string, max = 1000000000000) {
  const n = Number(raw);
  if (!Number.isSafeInteger(n) || n < 0 || n > max) throw new Error("Nominal atau angka tidak valid.");
  return n;
}
const validEmail = (email: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

export async function loginAction(form: FormData) {
  const email = value(form, "email").toLowerCase();
  const password = value(form, "password");
  const rows = await sql`SELECT id,email,password_hash,role,active,expires_at FROM users WHERE email=${email} LIMIT 1`;
  const user = rows[0];
  if (!validEmail(email) || !user || !user.active || !(await verifyPassword(password, String(user.password_hash)))) redirect("/login?error=invalid");
  if (user.role === "reseller" && user.expires_at && new Date(user.expires_at) <= new Date()) redirect("/login?error=expired");
  await createSession({ id: Number(user.id), email: String(user.email), role: user.role });
  redirect("/dashboard");
}
export async function logoutAction() { await destroySession(); redirect("/login"); }

export async function createKeyAction(form: FormData) {
  const user = await getSession(); if (!user) redirect("/login");
  const days = integer(value(form, "days"), 36500);
  const devices = integer(value(form, "devices"), 10000);
  const price = integer(value(form, "price"));
  if (devices < 1) throw new Error("Max device minimal 1.");
  const expires = days === 0 ? null : new Date(Date.now() + days * 86400000);
  const key = "ICAL-" + crypto.randomUUID().replaceAll("-", "").slice(0, 16).toUpperCase();
  await sql`INSERT INTO license_keys(key_value,created_by,expires_at,max_devices,price) VALUES(${key},${user.id},${expires},${devices},${price})`;
  revalidatePath("/dashboard/keys"); redirect("/dashboard/keys?created=1");
}
export async function requestTopupAction(form: FormData) {
  const user = await getSession(); if (!user) redirect("/login");
  const amount = integer(value(form, "amount"));
  if (amount < 1000) throw new Error("Minimum top up Rp1.000.");
  const note = value(form, "note").slice(0, 300);
  await sql`INSERT INTO topups(user_id,amount,note,status) VALUES(${user.id},${amount},${note || null},'pending')`;
  revalidatePath("/dashboard/topup"); redirect("/dashboard/topup?requested=1");
}
export async function reviewTopupAction(form: FormData) {
  const owner = await requireOwner();
  const id = integer(value(form, "topup_id"));
  const decision = value(form, "decision");
  if (!["approve", "reject"].includes(decision)) throw new Error("Keputusan tidak valid.");
  await sql.begin(async tx => {
    const rows = await tx`SELECT * FROM topups WHERE id=${id} FOR UPDATE`;
    const topup = rows[0];
    if (!topup || topup.status !== "pending") throw new Error("Permintaan ini sudah diproses.");
    if (decision === "approve") {
      await tx`UPDATE users SET balance=balance+${Number(topup.amount)} WHERE id=${Number(topup.user_id)}`;
      await tx`INSERT INTO ledger(actor_id,user_id,amount,kind,note) VALUES(${owner.id},${Number(topup.user_id)},${Number(topup.amount)},'topup',${"Top up #" + id})`;
    }
    await tx`UPDATE topups SET status=${decision === "approve" ? "approved" : "rejected"},reviewed_by=${owner.id},reviewed_at=NOW() WHERE id=${id}`;
  });
  revalidatePath("/dashboard/topup"); revalidatePath("/dashboard"); redirect("/dashboard/topup?reviewed=1");
}
export async function transferBalanceAction(form: FormData) {
  const owner = await requireOwner();
  const email = value(form, "email").toLowerCase();
  const amount = integer(value(form, "amount"));
  if (amount < 1 || !validEmail(email) || email === owner.email) throw new Error("Email atau nominal tidak valid.");
  await sql.begin(async tx => {
    const ownerRows = await tx`SELECT balance FROM users WHERE id=${owner.id} FOR UPDATE`;
    const recipientRows = await tx`SELECT id,role,active,expires_at FROM users WHERE email=${email} FOR UPDATE`;
    const recipient = recipientRows[0];
    if (!ownerRows[0] || Number(ownerRows[0].balance) < amount) throw new Error("Saldo owner tidak cukup.");
    if (!recipient || recipient.role !== "reseller" || !recipient.active || (recipient.expires_at && new Date(recipient.expires_at) <= new Date())) throw new Error("Reseller aktif tidak ditemukan.");
    await tx`UPDATE users SET balance=balance-${amount} WHERE id=${owner.id}`;
    await tx`UPDATE users SET balance=balance+${amount} WHERE id=${Number(recipient.id)}`;
    await tx`INSERT INTO ledger(actor_id,user_id,amount,kind,note) VALUES(${owner.id},${Number(recipient.id)},${amount},'transfer','Transfer saldo dari owner')`;
  });
  revalidatePath("/dashboard"); redirect("/dashboard/transfer?success=1");
}
export async function createResellerAction(form: FormData) {
  await requireOwner();
  const email = value(form, "email").toLowerCase();
  const password = value(form, "password");
  const days = integer(value(form, "days"), 36500);
  const balance = integer(value(form, "balance"));
  if (!validEmail(email) || password.length < 12 || password.length > 100) throw new Error("Email tidak valid atau password kurang dari 12 karakter.");
  const expires = days === 0 ? null : new Date(Date.now() + days * 86400000);
  const hash = await hashPassword(password);
  await sql`INSERT INTO users(email,password_hash,role,balance,expires_at,active) VALUES(${email},${hash},'reseller',${balance},${expires},TRUE)`;
  revalidatePath("/dashboard/resellers"); redirect("/dashboard/resellers?created=1");
}
export async function setResellerStatusAction(form: FormData) {
  await requireOwner();
  const id = integer(value(form, "user_id"));
  const active = value(form, "active") === "true";
  await sql`UPDATE users SET active=${active} WHERE id=${id} AND role='reseller'`;
  revalidatePath("/dashboard/resellers"); redirect("/dashboard/resellers");
}
