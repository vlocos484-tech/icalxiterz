import "server-only";
import postgres from "postgres";
if (!process.env.DATABASE_URL) console.warn("DATABASE_URL is not configured.");
export const sql = postgres(process.env.DATABASE_URL || "postgres://invalid:invalid@localhost:5432/invalid", { ssl: "require", max: 5, connect_timeout: 10, prepare: false });
