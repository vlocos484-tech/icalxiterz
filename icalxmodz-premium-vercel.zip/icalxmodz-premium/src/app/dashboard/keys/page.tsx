import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { sql } from "@/lib/db";
import { rupiah, dateLabel } from "@/lib/format";
export default async function KeysPage() {
  const user = await requireUser();
  const rows = user.role==="owner"
    ? await sql`SELECT k.id,k.key_value,k.expires_at,k.max_devices,k.price,k.active,k.created_at,u.email AS creator FROM license_keys k JOIN users u ON u.id=k.created_by ORDER BY k.id DESC LIMIT 200`
    : await sql`SELECT k.id,k.key_value,k.expires_at,k.max_devices,k.price,k.active,k.created_at,u.email AS creator FROM license_keys k JOIN users u ON u.id=k.created_by WHERE k.created_by=${user.id} ORDER BY k.id DESC LIMIT 200`;
  return <><p className="muted" style={{fontSize:12}}>PANEL / LICENSE KEYS</p><div style={{display:"flex",gap:12,alignItems:"center",justifyContent:"space-between",flexWrap:"wrap"}}><h1>List License Key</h1><Link className="btn" href="/dashboard/keys/new">+ Generate Key</Link></div><p className="muted">Menampilkan maksimal 200 key terbaru.</p>{rows.length===0?<div className="panel" style={{padding:20}}>Belum ada key. Buat key pertama lewat tombol Generate Key.</div>:<div className="panel table-wrap" style={{padding:8}}><table><thead><tr><th>Key</th><th>Dibuat oleh</th><th>Expired</th><th>Max device</th><th>Harga</th><th>Status</th></tr></thead><tbody>{rows.map(r=><tr key={r.id}><td style={{fontFamily:"monospace",overflowWrap:"anywhere"}}>{r.key_value}</td><td>{r.creator}</td><td>{dateLabel(r.expires_at)}</td><td>{r.max_devices}</td><td>{rupiah(r.price)}</td><td><span className="tag">{r.active?(r.expires_at&&new Date(r.expires_at)<new Date()?"Expired":"Aktif"):"Nonaktif"}</span></td></tr>)}</tbody></table></div>}</>;
}
