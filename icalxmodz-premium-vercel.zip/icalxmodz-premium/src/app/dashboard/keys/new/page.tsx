import Link from "next/link";
import { createKeyAction } from "@/lib/actions";
import { requireUser } from "@/lib/auth";
export default async function NewKeyPage() {
  await requireUser();
  return <><p className="muted" style={{fontSize:12}}>PANEL / GENERATE KEY</p><h1>Generate License Key</h1><p className="muted">Masa aktif 0 hari berarti permanen.</p><section className="panel" style={{padding:22,maxWidth:680}}><form action={createKeyAction} style={{display:"grid",gap:16}}><div className="form-grid"><label>Masa aktif (hari)<input className="field" type="number" name="days" min="0" max="36500" defaultValue="30" required/><small className="muted">0 = permanen</small></label><label>Max device<input className="field" type="number" name="devices" min="1" max="10000" defaultValue="1" required/></label><label>Harga (IDR)<input className="field" type="number" name="price" min="0" defaultValue="0" required/></label></div><div style={{display:"flex",gap:10,flexWrap:"wrap"}}><button className="btn" type="submit">Generate Key</button><Link className="btn btn-secondary" href="/dashboard/keys">Batal</Link></div></form></section></>;
}
