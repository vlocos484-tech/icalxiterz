import { requireOwner } from "@/lib/auth";
import { transferBalanceAction } from "@/lib/actions";
import { sql } from "@/lib/db";
import { rupiah, dateLabel } from "@/lib/format";
export default async function TransferPage({ searchParams }: { searchParams: { success?: string } }) {
  const owner = await requireOwner();
  const rows = await sql`SELECT l.id,l.amount,l.note,l.created_at,u.email FROM ledger l JOIN users u ON u.id=l.user_id WHERE l.actor_id=${owner.id} AND l.kind='transfer' ORDER BY l.id DESC LIMIT 50`;
  return <><p className="muted" style={{fontSize:12}}>PANEL / TRANSFER</p><h1>Transfer Saldo Owner</h1><p className="muted">Hanya owner yang bisa memindahkan saldo ke reseller aktif.</p>{searchParams?.success&&<p className="tag">Transfer berhasil.</p>}<section className="panel" style={{padding:22,maxWidth:650,marginBottom:20}}><p>Saldo owner: <strong>{rupiah(owner.balance||0)}</strong></p><form action={transferBalanceAction} style={{display:"grid",gap:14}}><label>Email reseller<input className="field" name="email" type="email" required placeholder="reseller@email.com"/></label><label>Nominal transfer (IDR)<input className="field" name="amount" type="number" min="1" required/></label><button className="btn" type="submit">Transfer Saldo</button></form></section><h2>Riwayat transfer terbaru</h2><div className="panel table-wrap" style={{padding:8}}><table><thead><tr><th>Tanggal</th><th>Reseller</th><th>Nominal</th><th>Catatan</th></tr></thead><tbody>{rows.map(r=><tr key={r.id}><td>{dateLabel(r.created_at)}</td><td>{r.email}</td><td>{rupiah(r.amount)}</td><td>{r.note}</td></tr>)}</tbody></table></div></>;
}
