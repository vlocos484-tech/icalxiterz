import { requireUser } from "@/lib/auth";
import { sql } from "@/lib/db";
import { rupiah, dateLabel } from "@/lib/format";
export default async function Dashboard() {
  const user = await requireUser();
  const [keys,pending,resellerCount,recent] = await Promise.all([
    sql`SELECT COUNT(*)::int AS n FROM license_keys WHERE created_by=${user.id}`,
    user.role==="owner" ? sql`SELECT COUNT(*)::int AS n FROM topups WHERE status='pending'` : sql`SELECT COUNT(*)::int AS n FROM topups WHERE user_id=${user.id} AND status='pending'`,
    user.role==="owner" ? sql`SELECT COUNT(*)::int AS n FROM users WHERE role='reseller'` : Promise.resolve([{n:0}]),
    sql`SELECT id,amount,kind,note,created_at FROM ledger WHERE user_id=${user.id} ORDER BY id DESC LIMIT 5`
  ]);
  return <><p className="muted" style={{fontSize:12}}>PANEL / OVERVIEW</p><h1 style={{marginTop:0}}>Dashboard {user.role==="owner"?"Owner":"Reseller"}</h1><p className="muted">Selamat datang, {user.email}.</p>
    <div className="grid-cards" style={{marginTop:24}}><div className="panel" style={{padding:20}}><div className="muted">Saldo tersedia</div><h2>{rupiah(user.balance||0)}</h2></div><div className="panel" style={{padding:20}}><div className="muted">Key dibuat oleh kamu</div><h2>{keys[0].n}</h2></div><div className="panel" style={{padding:20}}><div className="muted">{user.role==="owner"?"Jumlah reseller":"Top up pending"}</div><h2>{user.role==="owner"?resellerCount[0].n:pending[0].n}</h2></div></div>
    {user.role==="owner"&&<div className="panel" style={{padding:20,marginTop:18}}><h3 style={{marginTop:0}}>Tindakan owner</h3><p className="muted">Kelola reseller, tinjau permintaan top up, dan transfer saldo lewat menu di samping.</p></div>}
    <div className="panel" style={{padding:20,marginTop:18}}><h3 style={{marginTop:0}}>Aktivitas saldo terbaru</h3>{recent.length===0?<p className="muted">Belum ada transaksi.</p>:<div className="table-wrap"><table><thead><tr><th>Tanggal</th><th>Jenis</th><th>Nominal</th><th>Catatan</th></tr></thead><tbody>{recent.map(r=><tr key={r.id}><td>{dateLabel(r.created_at)}</td><td>{r.kind}</td><td>{rupiah(r.amount)}</td><td>{r.note||"—"}</td></tr>)}</tbody></table></div>}</div>
  </>;
}
