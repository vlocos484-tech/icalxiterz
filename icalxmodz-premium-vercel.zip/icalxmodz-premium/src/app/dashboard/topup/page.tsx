import { requireUser } from "@/lib/auth";
import { sql } from "@/lib/db";
import { requestTopupAction, reviewTopupAction } from "@/lib/actions";
import { rupiah, dateLabel } from "@/lib/format";
export default async function TopupPage({ searchParams }: { searchParams: { requested?: string; reviewed?: string } }) {
  const user = await requireUser();
  const rows = user.role==="owner"
    ? await sql`SELECT t.id,t.amount,t.note,t.status,t.created_at,u.email FROM topups t JOIN users u ON u.id=t.user_id ORDER BY CASE WHEN t.status='pending' THEN 0 ELSE 1 END,t.id DESC LIMIT 200`
    : await sql`SELECT id,amount,note,status,created_at FROM topups WHERE user_id=${user.id} ORDER BY id DESC LIMIT 100`;
  return <><p className="muted" style={{fontSize:12}}>PANEL / TOP UP</p><h1>{user.role==="owner"?"Persetujuan Top Up":"Top Up Saldo"}</h1>{searchParams?.requested&&<p className="tag">Permintaan top up dikirim.</p>}{searchParams?.reviewed&&<p className="tag">Permintaan berhasil diproses.</p>}
    {user.role==="reseller"&&<section className="panel" style={{padding:22,maxWidth:650,marginBottom:20}}><h3 style={{marginTop:0}}>Ajukan top up manual</h3><p className="muted">Owner akan memeriksa pembayaran sebelum saldo ditambahkan.</p><form action={requestTopupAction} style={{display:"grid",gap:14}}><label>Nominal (minimal Rp1.000)<input className="field" type="number" min="1000" name="amount" required/></label><label>Catatan / referensi pembayaran<input className="field" name="note" maxLength={300} placeholder="Contoh: transfer bank, waktu transfer"/></label><button className="btn" type="submit">Kirim Permintaan</button></form></section>}
    <section className="panel table-wrap" style={{padding:8}}><table><thead><tr><th>ID / Tanggal</th>{user.role==="owner"&&<th>Reseller</th>}<th>Nominal</th><th>Catatan</th><th>Status</th>{user.role==="owner"&&<th>Aksi</th>}</tr></thead><tbody>{rows.map(r=><tr key={r.id}><td>#{r.id}<br/><span className="muted">{dateLabel(r.created_at)}</span></td>{user.role==="owner"&&<td>{r.email}</td>}<td>{rupiah(r.amount)}</td><td>{r.note||"—"}</td><td><span className="tag">{r.status}</span></td>{user.role==="owner"&&<td>{r.status==="pending"?<form action={reviewTopupAction} style={{display:"flex",gap:6,flexWrap:"wrap"}}><input type="hidden" name="topup_id" value={r.id}/><button className="btn" name="decision" value="approve">Approve</button><button className="btn btn-danger" name="decision" value="reject">Reject</button></form>:"—"}</td>}</tr>)}</tbody></table></section>
  </>;
}
