import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { logoutAction } from "@/lib/actions";
export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const user = await requireUser();
  const allLinks = [["Overview","/dashboard"],["Generate Key","/dashboard/keys/new"],["List Key","/dashboard/keys"],["Top Up Saldo","/dashboard/topup"],["Transfer Saldo","/dashboard/transfer"],["Manajemen Reseller","/dashboard/resellers"]];
  const links = allLinks.filter(([,href]) => user.role === "owner" || !["/dashboard/transfer","/dashboard/resellers"].includes(href as string));
  return <div className="layout"><aside className="sidebar">
    <Link href="/dashboard" className="brand" style={{display:"block",fontSize:23,fontWeight:900,fontStyle:"italic",marginBottom:8}}>✦ ICAL<span style={{color:"#ff3921"}}>XMODZ</span></Link>
    <div className="muted" style={{fontSize:12,marginBottom:25}}>@icalxmodz · {user.role.toUpperCase()}</div>
    <nav className="nav-items">{links.map(([name,href])=><Link className="nav-link" href={href as string} key={href}>◇ {name}</Link>)}</nav>
    <div className="panel account-box" style={{position:"absolute",bottom:20,left:20,right:20}}><div style={{padding:12,fontSize:12,overflowWrap:"anywhere"}}>{user.email}<form action={logoutAction} style={{marginTop:10}}><button className="btn btn-secondary" type="submit" style={{width:"100%"}}>Keluar</button></form></div></div>
    <div className="mobile-logout" style={{marginTop:12,display:"none"}}><form action={logoutAction}><button className="btn btn-secondary" type="submit">Keluar</button></form></div>
  </aside><main className="content">{children}</main></div>;
}
