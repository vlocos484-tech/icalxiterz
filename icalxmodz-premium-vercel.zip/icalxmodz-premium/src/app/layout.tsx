import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title: "ICALXMODZ — Premium Panel", description: "ICALXMODZ license and reseller management panel" };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="id"><body><div className="shell">{children}</div></body></html>;
}
