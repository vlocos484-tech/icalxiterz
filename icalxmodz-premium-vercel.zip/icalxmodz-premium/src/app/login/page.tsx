import { loginAction } from "@/lib/actions";
export default function Login({ searchParams }: { searchParams: { error?: string } }) {
  return <main className="login-bg" style={{minHeight:"100vh",display:"grid",placeItems:"center",padding:20}}>
    <section className="panel" style={{width:"100%",maxWidth:460,padding:28,position:"relative"}}>
      <div style={{textAlign:"center",marginBottom:22}}>
        <img src="/logo.png" alt="ICALXMODZ logo" style={{width:96,height:96,objectFit:"contain",filter:"drop-shadow(0 0 14px #ff3b2280)"}}/>
        <div className="brand" style={{fontSize:31,fontWeight:900,fontStyle:"italic"}}>ICAL<span style={{color:"#ff3921"}}>XMODZ</span></div>
        <div style={{fontSize:11,letterSpacing:5,color:"#ff7056",marginTop:5}}>PREMIUM LICENSE PANEL</div>
        <p className="muted" style={{fontSize:13}}>Akses cepat, aman, dan terpercaya.</p>
      </div>
      <h2 style={{marginBottom:6}}>LOGIN</h2><p className="muted" style={{fontSize:13}}>Masukkan email dan password untuk melanjutkan ke dashboard.</p>
      {searchParams?.error && <p style={{background:"#351c20",padding:10,borderRadius:8,color:"#ffad9b"}}>Login gagal. Periksa email dan password kamu.</p>}
      <form action={loginAction} style={{display:"grid",gap:14}}>
        <label>Email<input className="field" name="email" type="email" placeholder="Username / Email" autoComplete="username" required /></label>
        <label>Password<input className="field" name="password" type="password" placeholder="Password" autoComplete="current-password" required /></label>
        <button className="btn" type="submit" style={{padding:14,marginTop:4}}>Masuk ke Dashboard　→</button>
      </form>
      <div style={{textAlign:"center",marginTop:22,paddingTop:18,borderTop:"1px solid #30201e",fontSize:13}}>
        <p className="muted" style={{marginBottom:9}}>Belum punya akun?</p>
        <p style={{margin:0}}>✈ <span style={{color:"#ff5a3f"}}>Daftar</span> reseller, PM owner <a href="https://t.me/icalxmodz" target="_blank" rel="noopener noreferrer" style={{color:"#ff5a3f",fontWeight:700,textDecoration:"underline"}}>@icalxmodz</a></p>
      </div>
      <div style={{display:"flex",justifyContent:"space-around",gap:8,borderTop:"1px solid #30201e",marginTop:24,paddingTop:17,fontSize:11,color:"#bbb",textAlign:"center"}}>
        <div><b style={{color:"#ff4a2d"}}>◇</b><br/>Aman</div><div><b style={{color:"#ff4a2d"}}>ϟ</b><br/>Cepat</div><div><b style={{color:"#ff4a2d"}}>♛</b><br/>Premium</div><div><b style={{color:"#ff4a2d"}}>◉</b><br/>Support</div>
      </div>
      <p className="muted" style={{fontSize:10,marginTop:22,textAlign:"center"}}>© ICALXMODZ · POWERED BY ICALXMODZ</p>
    </section>
  </main>;
}
