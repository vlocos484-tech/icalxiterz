import postgres from "postgres";
import bcrypt from "bcryptjs";
const { DATABASE_URL, OWNER_EMAIL, OWNER_PASSWORD } = process.env;
if (!DATABASE_URL || !OWNER_EMAIL || !OWNER_PASSWORD) { console.error("Set DATABASE_URL, OWNER_EMAIL, and OWNER_PASSWORD first."); process.exit(1); }
if (OWNER_PASSWORD.length < 12) { console.error("OWNER_PASSWORD must be at least 12 characters."); process.exit(1); }
const sql = postgres(DATABASE_URL, { ssl: "require", max: 1, prepare: false });
try {
  const email = OWNER_EMAIL.trim().toLowerCase();
  const existing = await sql`SELECT id, role FROM users WHERE email=${email} LIMIT 1`;
  const hash = await bcrypt.hash(OWNER_PASSWORD, 12);
  if (existing.length) {
    if (existing[0].role !== "owner") throw new Error("Email already belongs to a non-owner account.");
    await sql`UPDATE users SET password_hash=${hash}, active=TRUE WHERE email=${email}`;
    console.log("Existing owner password updated.");
  } else {
    await sql`INSERT INTO users(email,password_hash,role,balance,active) VALUES(${email},${hash},'owner',0,TRUE)`;
    console.log("Owner account created.");
  }
} catch (e) { console.error("Owner seed failed:", e.message); process.exitCode = 1; }
finally { await sql.end(); }
