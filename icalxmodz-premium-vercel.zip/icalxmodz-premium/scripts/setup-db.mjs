import postgres from "postgres";
import { readFile } from "node:fs/promises";
if (!process.env.DATABASE_URL) { console.error("Set DATABASE_URL first."); process.exit(1); }
const sql = postgres(process.env.DATABASE_URL, { ssl: "require", max: 1, prepare: false });
try {
  const schema = await readFile(new URL("../database/schema.sql", import.meta.url), "utf8");
  await sql.unsafe(schema);
  console.log("Database schema installed.");
} catch (e) {
  console.error("Schema setup failed:", e.message);
  process.exitCode = 1;
} finally { await sql.end(); }
